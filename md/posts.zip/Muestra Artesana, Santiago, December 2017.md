﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/muestra-artesania-santiago-december-2017
  * Author:: [[Loop]]
  * Tags:: [[Chile]]
  * Date:: [[17 January 2018]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2018/01/Slide1.jpg)](https://garlandmag.com/wp-content/uploads/2018/01/Slide1.jpg)
[![](https://garlandmag.com/wp-content/uploads/2018/01/Slide2.jpg)](https://garlandmag.com/wp-content/uploads/2018/01/Slide2.jpg)
[![](https://garlandmag.com/wp-content/uploads/2018/01/Slide3.jpg)](https://garlandmag.com/wp-content/uploads/2018/01/Slide3.jpg)
  

[![](https://garlandmag.com/wp-content/uploads/2018/01/Slide4.jpg)](https://garlandmag.com/wp-content/uploads/2018/01/Slide4.jpg)
[![](https://garlandmag.com/wp-content/uploads/2018/01/Slide5.jpg)](https://garlandmag.com/wp-content/uploads/2018/01/Slide5.jpg)
[![](https://garlandmag.com/wp-content/uploads/2018/01/Slide6.jpg)](https://garlandmag.com/wp-content/uploads/2018/01/Slide6.jpg)
  

[![](https://garlandmag.com/wp-content/uploads/2018/01/Slide7.jpg)](https://garlandmag.com/wp-content/uploads/2018/01/Slide7.jpg)
[![](https://garlandmag.com/wp-content/uploads/2018/01/Slide8.jpg)](https://garlandmag.com/wp-content/uploads/2018/01/Slide8.jpg)
  

Fresh from the [44th International Show of Traditional Crafts](http://artesania.uc.cl/) in Santiago, Chile, the President of World Crafts Council - Latin America, Alberto de Betolaza, shares with us some images of this important continental event. 
