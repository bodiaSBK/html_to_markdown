﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/garland-10-launch
  * Author:: [[Loop]]
  * Tags:: [[launch]] [[Western Australia]]
  * Date:: [[12 February 2018]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2018/02/ContactSheet-001.jpg)](https://garlandmag.com/wp-content/uploads/2018/02/ContactSheet-001.jpg)
[![](https://garlandmag.com/wp-content/uploads/2018/02/WA-postcard-front-215x300.jpg)](https://garlandmag.com/wp-content/uploads/2018/02/WA-postcard-front.jpg)"All stories, from the joyous to the sorrowful have a belonging, they are a part of who we are." - Glenn Iseger-Pilkington
Join us at the launch of Garland #10 at the Fremantle Arts Centre.
Wednesday 28 March 2018
5:30pm conversation with contributors
6:30pm launch with the opening of [Sensual Nature](https://www.fac.org.au/whats-on/post/sensual-nature/) exhibition.
[Facebook event page](https://www.facebook.com/events/222143531856842/)
