﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/paola-moreno-democracy
  * Author:: [[Loop]]
  * Tags:: [[Chile]] [[flag]] [[spanish]] [[textiles]]
  * Date:: [[23 October 2019]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2019/10/75075670_10220658068140985_7187974536925544448_o-e1571794464337-1024x607.jpg)](https://garlandmag.com/wp-content/uploads/2019/10/75075670_10220658068140985_7187974536925544448_o.jpg)
Paola Moreno and Carolina Varela, Chilean flag, 2019, boro technique
Textile artists can [re-make flags](https://garlandmag.com/article/nations-unravelled-and-re-woven/) to give a human dimension to a nation. Paola Moreno and Carolina Varela have made a powerful work in immediate response to the current crisis in Chilean democracy.
Paola Moreno writes about this:
> Un pequeño trozo de tela puede ser el textil más fuerte si todas las partes se unen por un bien común. Desde nuestro querido taller deseamos que Chile sea fortalecido con esta crisis, que logre la equidad tan esperada y la unidad dentro de sus diferencias ❤️
Translated: A small piece of cloth can be the stronger if all the parts are joined together for a common good. From our beloved workshop we want Chile to be strengthened with this crisis, to achieve the long-awaited equity and unity within its differences.
 _Paola Moreno and Carolina Varela are co-founders of the Centro de Arte Textil in Santiago. Instagram: @cat.centroartetextil, @cvdiseño and[@spaolamorenom](https://www.instagram.com/spaolamorenom/)_
