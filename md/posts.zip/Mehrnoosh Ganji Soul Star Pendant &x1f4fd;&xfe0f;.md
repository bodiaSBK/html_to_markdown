﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/mehrnoosh-ganji-%e2%9c%bf-soul-star-pendant
  * Author:: [[Loop]]
  * Tags:: [[jewellery]] [[Mark Newbound]] [[Persian Prospect]] [[video]]
  * Date:: [[8 May 2019]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2019/05/IMG_0001_2-1024x678.jpg)](https://garlandmag.com/wp-content/uploads/2019/05/IMG_0001_2.jpg)
Mehrnoosh Ganji, Soul Star Pendant, 2019, sterling silver, fine silver, garnet, Plaque-a-jour enamel
A film by Mark Newbound captures the quiet focus and skill involved in the jewellery craft of Mehrnoosh Ganji. Soul Star Pendant reflects the spiritual values underlying its production.
The soul star pendant is a piece from the Soul Star collection, which is inspired by mysticism and ancient architecture. The soul star in some spiritual practices is associated with the origin of enlightenment and ascension. The structure of this piece contains several levels focusing upward to shape a unified composition which is a metaphor for the soul's journey and seeking transcendence. Plaque-a-jour enamel patterns are letting the light come in like the stain glass windows in ancient architecture. It finishes with a coloured gemstone on the top and as an enlightened soul spreads love and beauty out into the world.
