﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/emma-davies-weaves-a-world-from-twine-and-bone
  * Author:: [[Loop]]
  * Tags:: [[Mark Newbound]] [[plastic]] [[video]]
  * Date:: [[18 June 2018]]


* * *
The latest slow take from[ Mark Newbound](https://vimeo.com/newbound) features[ Emma Davies](http://www.emmadavies.com.au/) in her Mornington studio creating a sculpture from twine and seal bones. 
Mark Newbound reflects on the experience:
> From the right spot in the kitchen of Emma Davies’ mud brick home, you can just make out the Melbourne skyline across the bay. There she told me about the beach she goes to from time to time to gather washed up seal bones. I meant to ask her how she came to use hay baling twine in her sculptures but forgot. We spent the day filming in the attached studio, while the arc of the sun shifted the light around. In the early stages her process reminded me of spider webs. I was surprised how much she improvised, cutting here and adding there, pausing to weigh it all up. Later while putting the footage together this all seemed similar to editing. On leaving she gave me some small mesh vessels she had made. Back home my daughter filled one with dried wildflowers we’d collected in the Victorian Alps.
And according to Emma, "Mark Newbound's short films brilliantly captures the artist and their process in a very unique and intimate way. His camera and sound allows the viewer to almost be present in the making, an art in itself." We'll let you know when _Bag of Bones_ is on display.
