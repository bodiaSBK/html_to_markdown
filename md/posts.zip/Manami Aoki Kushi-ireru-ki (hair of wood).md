﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/aoki
  * Author:: [[Loop]]
  * Tags:: [[fibre]] [[Japan]] [[jewellery]] [[laurel]]
  * Date:: [[6 March 2019]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2019/03/「kushi-ireru-ki」long.jpg)](https://garlandmag.com/wp-content/uploads/2019/03/「kushi-ireru-ki」long.jpg)
Manami Aoki, Kushi-ireru-ki, 2019, Japanese cypress, H335 x W100 x D3mm
Our laurel for March 2019 goes to emerging Tokyo jeweller Manami Aoki.
Her first solo [exhibition](https://holeinthewall.tokyo/exhibition/kurashitosoushingu/) at Hiko Mizuno Jewelry College featured poignant works the imbued humble objects and materials with a life spirit. As Manami Aoki writes for this exhibition, "I live with jewellery. It means that I constantly consider how to wear objects found in my everyday life."
 _Kushi-_ ireru _-ki_ means  "wood that can be combed" or "hair of wood". This work took about a week to fiberise the piece of cedar. "I hammered it little by little and I proceeded a certain length per day in order to maintain focus."
[![](https://garlandmag.com/wp-content/uploads/2019/03/2019-02-15-18.12.02-1024x840.jpg)](https://garlandmag.com/wp-content/uploads/2019/03/2019-02-15-18.12.02.jpg)
     Mamani Aoki
[![](https://garlandmag.com/wp-content/uploads/2019/03/2019-02-15-18.40.53.jpg)](https://garlandmag.com/wp-content/uploads/2019/03/2019-02-15-18.40.53.jpg)
     Mamani Aoki
  

 
You can learn more about Aimi's work on her [website](https://manami-aoki.wixsite.com/manami-aoki) and follow her on Instagram at [@_manami__aoki_](https://www.instagram.com/_manami__aoki_/)
Thanks to Makiko Akiyama for help with translation. 
