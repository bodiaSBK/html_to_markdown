﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/cultural-attache
  * Author:: [[Loop]]
  * Tags:: 
  * Date:: [[23 October 2018]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2018/10/Saibai-Island-Dancers-Women.jpg)](https://garlandmag.com/wp-content/uploads/2018/10/Saibai-Island-Dancers-Women.jpg)
Saibai Island Dancers - Women, photo courtesy of Leitha Assan
Garland sustains a network of writers and makers from the wider world. It is important to acknowledge the relevant festivals that figure in the many different cultures of the Indo-Pacific. Most of the festivals in the Western world have become private events, such as Valentines, Mothers or Fathers Days. People come together in their name only to shop. There is much to learn from the calendar events in the wider world, such as the day of silence in Bali or the upcoming Diwali festival of light in India.
Garland needs a creative person who can give one or two hours a week to developing and sharing this cultural calendar. This involves working on our collaborative online platform and creating digital cards that can be shared across our channels. There is scope to expand this if capacity permits.
Garland needs someone who is curious, generous of spirit, creative, digitally literate and committed to enriching our world through diversity. In return, you will share the experience of producing a digital publication and develop an international network.
The Cultural Attaché will report to the Managing Editor and work remotely. Where possible, he or she will be involved in Garland events. The position is available for 12 months with a three month probation period. If you are interested, please send a paragraph about yourself including personal links and a day you think should be shared with Garland readers and writers.
Applications are due 16 November 2018 and can be submitted [here](https://goo.gl/forms/XUOTiXaGYiw0X3Ag1). 
