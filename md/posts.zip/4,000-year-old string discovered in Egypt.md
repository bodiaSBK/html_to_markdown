﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/4000-year-old-string-discovered-in-egypt
  * Author:: [[Loop]]
  * Tags:: [[Egypt]] [[fibre]] [[string]]
  * Date:: [[7 August 2018]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2018/08/cave-ropes-string-1200x808-1024x689-2.jpg)](https://garlandmag.com/wp-content/uploads/2018/08/cave-ropes-string-1200x808.jpg)
At Garland, we love stories of string. Robyn McKenzie's essay on [string-figures](https://garlandmag.com/article/quarterly-essay-remembering-the-string-figures-of-yirrkala/) is particularly memorable. This rich article from a publication about coastal cultures includes the story of how perfectly preserved papyrus rope was discovered in a man-made cave in the ancient Egyptian harbour of Saww. String-lovers will enjoy this.
Source: _[The Long, Knotty, World-Spanning Story of String | Hakai Magazine](https://www.hakaimagazine.com/features/the-long-knotty-world-spanning-story-of-string/)_
