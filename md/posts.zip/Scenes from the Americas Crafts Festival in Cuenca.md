﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/scenes-from-the-americas-crafts-festival-in-cuenca
  * Author:: [[Mari Gold]]
  * Tags:: [[Ecuador]] [[Latin America]] [[World Crafts Council]]
  * Date:: [[19 November 2017]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2017/11/Slide1.jpg)](https://garlandmag.com/wp-content/uploads/2017/11/Slide1.jpg)
[![](https://garlandmag.com/wp-content/uploads/2017/11/Slide2.jpg)](https://garlandmag.com/wp-content/uploads/2017/11/Slide2.jpg)
[![](https://garlandmag.com/wp-content/uploads/2017/11/Slide3.jpg)](https://garlandmag.com/wp-content/uploads/2017/11/Slide3.jpg)
  

[![](https://garlandmag.com/wp-content/uploads/2017/11/Slide4.jpg)](https://garlandmag.com/wp-content/uploads/2017/11/Slide4.jpg)
[![](https://garlandmag.com/wp-content/uploads/2017/11/Slide5.jpg)](https://garlandmag.com/wp-content/uploads/2017/11/Slide5.jpg)
[![](https://garlandmag.com/wp-content/uploads/2017/11/Slide6.jpg)](https://garlandmag.com/wp-content/uploads/2017/11/Slide6.jpg)
  

[![](https://garlandmag.com/wp-content/uploads/2017/11/Slide7.jpg)](https://garlandmag.com/wp-content/uploads/2017/11/Slide7.jpg)
[![](https://garlandmag.com/wp-content/uploads/2017/11/Slide8.jpg)](https://garlandmag.com/wp-content/uploads/2017/11/Slide8.jpg)
[![](https://garlandmag.com/wp-content/uploads/2017/11/Slide9.jpg)](https://garlandmag.com/wp-content/uploads/2017/11/Slide9.jpg)
  

From October 27 to November 5 _The Americas Crafts Festival_ took place in Cuenca (Ecuador). It was organized by the Inter-American Center of Popular Arts, which carefully selected the 150 artisans who were exhibiting their crafts in the booths along the Tomebamba river.
From the 150 artisans, 28 were foreigners belonging to ten countries (Indonesia, Argentina, Bolivia, Chile, Colombia, Peru, Uruguay, Venezuela and Japan). The 122 local artisans were divided in two groups: traditional and contemporary artisans.
During the event, a contest was organized giving 3 main prizes, two of them were selected by a Jury: 1) international artisan; 2) local artisan. The third one was decided by the visitors.
Information and images provided by Alberto de Bertolaza, President World Crafts Council - Latin America
 
