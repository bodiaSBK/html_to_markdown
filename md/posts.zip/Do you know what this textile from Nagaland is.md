﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/textile-from-nagaland
  * Author:: [[Loop]]
  * Tags:: [[India]] [[textiles]]
  * Date:: [[5 December 2018]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2018/12/IMG_9642.jpeg)](https://garlandmag.com/wp-content/uploads/2018/12/IMG_9642.jpeg)
The cloths that bind us has become a strong theme in Garland stories. Please note this query about a sash from the Indian north-east state of Nagaland. 
Kelly Grimshaw is a Conservation masters student at the University of Lincoln and is currently working with an object which has been labelled ‘Naga loin cloth’.
There is little information provided within her department, so she is reaching out to museums to see if there is any information regarding its origins, its use. "I do not believe it is a loin cloth, but rather a sash, and if it originally belonged to the Naga tribes in Nagaland."
If there are any similar objects within your collection that would support its origin from Nagaland, that would be extremely helpful.
Please leave a comment below if you have any ideas.
