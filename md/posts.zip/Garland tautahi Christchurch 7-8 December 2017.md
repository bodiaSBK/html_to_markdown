﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/christchurch
  * Author:: [[Mari Gold]]
  * Tags:: [[Christchurch]] [[event]] [[launch]]
  * Date:: [[27 November 2017]]


* * *
[![](http://garlandmag.com/wp-content/uploads/2017/11/FT_NMHM_A3BrochureBlue_vW-1024x724.jpg)](http://garlandmag.com/wp-content/uploads/2017/11/FT_NMHM_A3BrochureBlue_vW-1024x724.jpg)
### Garland launch
The Te Moana Nui a Kiwa issue of Garland magazine will be launched as part of Christchurch's First Thursday program.
Join us at the opening of Warp & Weft, curated by Audrey Baldwin, at [Dilana Rugs,   
](http://dilana.co.nz/)Thursday, 7 December, from 5:30pm  
102 Buchan Street, Sydenham, Ōtautahi Christchurch
 
### Garland forum
Join the editor Kevin Murray and local contributors, [Warren Feeney](http://garlandmag.com/article/a-considered-and-cordial-welcome-michael-parekowhais-ten-guitars-and-the-lighthouse/), [Harriet Litten](http://garlandmag.com/article/casting-shadows-areta-wilkinson-and-mark-adams-at-the-national/) and [Bojana Rimbovska](http://garlandmag.com/article/nina-oberg-alaifea-and-stephanie-oberg/) discuss the questions raised by this issue about the cultural identity of Moana today and the status of customary practices in new urban contexts. 
Friday, 8 December, 10-11:30am  
University of Canterbury Pasfika Lali Seminar Room  
Macmillan Brown Pacific Studies Room 208  
Located on level two of the Te Ao Marama building ([map](http://www.canterbury.ac.nz/maps/home?poi=10810&z=17&c=-43.523795394281414%2C172.58676052093506))
