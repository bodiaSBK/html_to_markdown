﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/cheongju-2019
  * Author:: [[Loop]]
  * Tags:: [[call for works]] [[South Korea]]
  * Date:: [[31 July 2018]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2015/12/IMG_2810.jpg)](https://garlandmag.com/wp-content/uploads/2015/12/IMG_2810.jpg)
Garland began its journey in South Korea at the 2015 Cheongju International Craft Biennale (see the [article](https://garlandmag.com/article/hyeyoung-cho-presents-korean-craft-to-the-world/) by Hyeyoung Cho). We're pleased to support this important event by sharing its recent call for invited countries.
The Cheongju International Craft Biennale is the first (1999) and arguably the world's largest craft biennale. It attracts more than 300,000 visitors and contains 3,000 visiting artists from 60 countries (2015). The total exhibition area is 20,000sqm in an historical industrial building, which was Korea’s largest tobacco processing plant, located 1.5 hour from Seoul & 15 mins from Cheongju International Airport. 
The invited countries in the last Biennale were U.K, Singapore, Japan, Germany, Finland, Switzerland and Italy. The invited countries for next year's biennale will be provided an exhibition space, support for translation and publication cost in the catalogue, round-trip ticket and hotel fare for 2 staff, shipping costs for return of works, insurance and liabilities.
Related documents with details of this offer can be downloaded [here](https://app.box.com/s/znctpqcqdnn179hnye7hqbazun0qvdjf). 
 
