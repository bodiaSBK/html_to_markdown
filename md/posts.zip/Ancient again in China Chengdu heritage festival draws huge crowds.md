﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/ancient-again-in-china-chengdu-heritage-festival-draws-huge-crowds
  * Author:: [[XueXia]]
  * Tags:: [[ancient]] [[China]]
  * Date:: [[5 November 2019]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2019/11/15728357862032.jpg)](https://garlandmag.com/wp-content/uploads/2019/11/15728357862032.jpg)
[![](https://garlandmag.com/wp-content/uploads/2019/11/157224615470630.jpg)](https://garlandmag.com/wp-content/uploads/2019/11/157224615470630.jpg)
[![](https://garlandmag.com/wp-content/uploads/2019/11/157224615492966.jpg)](https://garlandmag.com/wp-content/uploads/2019/11/157224615492966.jpg)
  

[![](https://garlandmag.com/wp-content/uploads/2019/11/15719703494391.jpg)](https://garlandmag.com/wp-content/uploads/2019/11/15719703494391.jpg)
[![](https://garlandmag.com/wp-content/uploads/2019/11/157224615494281.jpg)](https://garlandmag.com/wp-content/uploads/2019/11/157224615494281.jpg)
  

The 7th Chengdu international intangible cultural heritage festival (17 - 22 October 2019) has concluded in Chengdu. The six-day carnival attracted a total of 5.7 million people, with an online population of 190 million people.
Over 500 exhibitors sold over 50 million yuan (about AU$10 million) and the contract amount exceeded 100 million yuan (about AU$20 million). In addition to the main venue, 18 theme sub-venues will be set up for the 2019 festival, which is
the largest in history. At the same time, 420 intangible cultural heritage activities held in the community.
[![](https://garlandmag.com/wp-content/uploads/2019/11/706550caly1g81gac4iv8j21900u07af-300x200.jpg)](https://garlandmag.com/wp-content/uploads/2019/11/706550caly1g81gac4iv8j21900u07af.jpg)
Craft princess Liziqi was a star attraction.
During the 7th Chengdu international intangible cultural heritage festival, 10 routes and 40 experience bases for intangible cultural heritage projects in Chengdu were officially unveiled. The 10 routes not only include Sichuan brocade, Shu embroidery, Chengdu lacquer art and other abundant intangible cultural heritage projects in Chengdu, but also include famous tourist resources such as Panda Breeding Research Base, Dufu cottage, Kuanzhai Alley, and new cultural landmarks. The 40 intangible cultural heritage project experience bases include the Chengdu lacquer craft factory, Zhanqi village 18 square, Anjing Shu embroidery park, Daoming bamboo art village, Yuantong ancient town, Sichuan cuisine cultural experience museum, etc.
During the festival, 20 foreign teams from New Zealand, the United States, Russia, Mexico, and other countries performed on the stage. There was Fijian traditional folk song and dance, Japanese traditional dance and Hawaiian hula dance. Poland's woven lace and Hungary's Easter egg painting were popular in the international traditional handicraft exhibition. Nearly 90 intangible cultural heritage projects from 36 countries gathered here, presenting a more diversified international festival of intangible cultural heritage. In addition to displaying the works of foreign craftsmen, the exhibition also exhibits for the first time the "hybrid" intangible cultural heritage products jointly created by Chinese and foreign intangible heritage masters.
