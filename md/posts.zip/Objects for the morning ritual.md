﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/objects-for-the-morning-ritual
  * Author:: [[Loop]]
  * Tags:: [[Adelaide]] [[ritual]]
  * Date:: [[22 April 2019]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2019/04/1-1024x957.jpg)](https://garlandmag.com/wp-content/uploads/2019/04/1.jpg)
The homemade altar for Daniel To and Emma Aiston
What role can objects play in making a morning ritual? Adelaide designers Daniel To and Emma Aiston have produced a range of objects that are used specifically to start the day.
 _Good Morning_ is a collection of objects focused around sunrise rituals which were designed and developed around their own morning routine. The range includes a stoneware mug, cup, tea canister and vase, timber tray, an aluminium incense holder, hand dyed tea towel and notebook. They say  "it is incredibly important to be surrounded by objects that bring about happiness and pleasure".
[![](https://garlandmag.com/wp-content/uploads/2019/04/NGV_03-01-2019-ÔÇô-Daniel-Emma_023.jpg)](https://garlandmag.com/wp-content/uploads/2019/04/NGV_03-01-2019-ÔÇô-Daniel-Emma_023.jpg)
     Good Morning Collection - Stoneware Vase. Image courtesy of NGV Design Store.
[![](https://garlandmag.com/wp-content/uploads/2019/04/NGV_03-01-2019-ÔÇô-Daniel-Emma_004.jpg)](https://garlandmag.com/wp-content/uploads/2019/04/NGV_03-01-2019-ÔÇô-Daniel-Emma_004.jpg)
  

Daniel To and Emma Aiston have jointly taken on the role of JamFactory Creative Directors, overseeing Ceramics, Glass, Furniture and Jewellery & Metal Studios. They ritual objects can be found at the NGV Design Store.
