﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/niloufar-mirshahidi-behnaz-barabarian-a-delicate-persian-love-story-to-fit-your-finger
  * Author:: [[Loop]]
  * Tags:: [[Iran]] [[jewellery]]
  * Date:: [[9 July 2018]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2018/07/WhatsApp-Image-2018-06-26-at-10.37.41-AM1.jpg)](https://garlandmag.com/wp-content/uploads/2018/07/WhatsApp-Image-2018-06-26-at-10.37.41-AM1.jpg)
     Niloufar Mirshahidi & Behnaz Barabarian, An Unrepeatable Amorous, 18k gold, turquoise, pearl, lazuli and brilliant
[![](https://garlandmag.com/wp-content/uploads/2018/07/Shahnameh-project2-1024x522.jpg)](https://garlandmag.com/wp-content/uploads/2018/07/Shahnameh-project2.jpg)
[![](https://garlandmag.com/wp-content/uploads/2018/07/finishing-process-1024x752.jpg)](https://garlandmag.com/wp-content/uploads/2018/07/finishing-process.jpg)
  

[![](https://garlandmag.com/wp-content/uploads/2018/07/a4.jpg)](https://garlandmag.com/wp-content/uploads/2018/07/a4.jpg)
  

This jewellery artwork is inspired by “Zal & Roudabeh”, one of the most beautiful love stories of _Shahnameh_. 
Roudabeh is Mehrab Kaboli’s daughter and Zal is Sam’s son with white-coloured hair that was raised by Simorgh (Phoenix).In the original story of _Shahnameh_ , Roudabeh, who has been Imprisoned in a palace, confronts Zal that has come to that palace to meet her. Then, Roudabeh drops her long and rope-like hair for Zal to make her free from prison. But Zal’s Iranian style of love and chastity prevents him touching and using her beloved hair as a rope. So he kisses her hair to show his respect and makes a rope by something else, not her hair, and finally saves Roudabeh from prison.
This story is one of the best and the most delicate Persian (Iranian) love stories.
Elements of this work include:
  * The Lotus Flower is one of the most ancient flower shapes in Persian history
  * Roudabeh’s dress has been inspired by ancient Persian women’s costumes
  * Original Persian colours and stones such as turquoise and lazuli
  * The altars in two sides of the ring, associate the Iranian-Islamic art
  * The ring roof motif has been inspired by Iranian tiles and Iranian inner home decoration in which the inlaid tiles are used.
  * The ring is designed like a mansion with columns and piles in each floor that represent the ancient Iranian architecture. 


In designing of this ring, the original source were two verses of Shahnameh composed by Ferdowsi:
> She made a rope by her long hair for her lover(Zal) to catch  
>  But Zal refused to use his beloved hair as a rope.
Creators: Niloufar Mirshahidi & Behnaz Barabarian
