﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/can-read-garland-print
  * Author:: [[Loop]]
  * Tags:: [[compendium]] [[Melbourne]]
  * Date:: [[28 January 2018]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2018/01/20180125_133024-e1517104937115-1024x816.jpg)](https://garlandmag.com/wp-content/uploads/2018/01/20180125_133024-e1517102763325.jpg)
Gaetan, manager at Choukette, with a copy of Jasmine - Garland Compendium on their bookshelf
Where do you go to read?
If you want to take 20 minutes out to follow the journey of a long-form essay, where can you find a convivial space to sit and read? Talking with Garland readers, we've found that the cafe is a popular place to take time out for reading during the day. So to help you out we're finding independent cafes across the Indo-Pacific which have a bookshelf and a convivial atmosphere, reflecting the care and creativity of the staff.
We'll be gradually accumulating these [reading posts](https://garlandmag.com/reading-posts/) over time. Feel free to [nominate](https://garlandmag.com/about/contact/) your favourite cafe.
We've just created our second reading post at Choukette Cafe in Brunswick, Melbourne. You can see a full list [here](https://garlandmag.com/reading-posts/).
