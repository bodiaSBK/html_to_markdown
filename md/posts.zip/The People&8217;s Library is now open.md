﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/the-peoples-library-is-now-open
  * Author:: [[Loop]]
  * Tags:: [[book]] [[Tasmania]] [[tunapri]]
  * Date:: [[26 September 2018]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2018/09/42480584_10214066683795278_2034038529327104000_o-1024x768.jpg)](https://garlandmag.com/wp-content/uploads/2018/09/42480584_10214066683795278_2034038529327104000_o.jpg)
     Justy Phillips and Margaret Woodward of A Published Event, courtesy Rosie Hastie for #ThePeoplesLibrary and Salamanca Arts Centre
[![](https://garlandmag.com/wp-content/uploads/2018/09/42418618_10214066683555272_8184031015405092864_o-1024x768.jpg)](https://garlandmag.com/wp-content/uploads/2018/09/42418618_10214066683555272_8184031015405092864_o.jpg)
     Justy Phillips and Margaret Woodward of A Published Event, courtesy Rosie Hastie for #ThePeoplesLibrary and Salamanca Arts Centre
[![](https://garlandmag.com/wp-content/uploads/2018/09/42379412_10214066688595398_5004665883809808384_o-1024x683.jpg)](https://garlandmag.com/wp-content/uploads/2018/09/42379412_10214066688595398_5004665883809808384_o.jpg)
     Justy Phillips and Margaret Woodward of A Published Event, courtesy Rosie Hastie for #ThePeoplesLibrary and Salamanca Arts Centre
  

[![](https://garlandmag.com/wp-content/uploads/2018/09/42508270_10214066688435394_1041990015543934976_o-1024x683.jpg)](https://garlandmag.com/wp-content/uploads/2018/09/42508270_10214066688435394_1041990015543934976_o.jpg)
     Justy Phillips and Margaret Woodward of A Published Event, courtesy Rosie Hastie for #ThePeoplesLibrary and Salamanca Arts Centre
[![](https://garlandmag.com/wp-content/uploads/2018/09/42411543_10214066686715351_6297413647920529408_o-1024x683.jpg)](https://garlandmag.com/wp-content/uploads/2018/09/42411543_10214066686715351_6297413647920529408_o.jpg)
     Justy Phillips and Margaret Woodward of A Published Event, courtesy Rosie Hastie for #ThePeoplesLibrary and Salamanca Arts Centre
[![](https://garlandmag.com/wp-content/uploads/2018/09/42452725_10214066684195288_3117904746589978624_o-1024x768.jpg)](https://garlandmag.com/wp-content/uploads/2018/09/42452725_10214066684195288_3117904746589978624_o.jpg)
     Justy Phillips and Margaret Woodward of A Published Event, courtesy Rosie Hastie for #ThePeoplesLibrary and Salamanca Arts Centre
  

[![](https://garlandmag.com/wp-content/uploads/2018/09/42458302_10214066685355317_2300527982889926656_o-1024x683.jpg)](https://garlandmag.com/wp-content/uploads/2018/09/42458302_10214066685355317_2300527982889926656_o.jpg)
     Justy Phillips and Margaret Woodward of A Published Event, courtesy Rosie Hastie for #ThePeoplesLibrary and Salamanca Arts Centre
[![](https://garlandmag.com/wp-content/uploads/2018/09/42374669_10214066684635299_5496828140468568064_o-1024x768.jpg)](https://garlandmag.com/wp-content/uploads/2018/09/42374669_10214066684635299_5496828140468568064_o.jpg)
     Justy Phillips and Margaret Woodward of A Published Event, courtesy Rosie Hastie for #ThePeoplesLibrary and Salamanca Arts Centre
[![](https://garlandmag.com/wp-content/uploads/2018/09/42459665_10214066684435294_8933304247924031488_o-1024x758.jpg)](https://garlandmag.com/wp-content/uploads/2018/09/42459665_10214066684435294_8933304247924031488_o.jpg)
     Justy Phillips and Margaret Woodward of A Published Event, courtesy Rosie Hastie for #ThePeoplesLibrary and Salamanca Arts Centre
  

[![](https://garlandmag.com/wp-content/uploads/2018/09/42429448_10214066685675325_5757002342838829056_o-1024x683.jpg)](https://garlandmag.com/wp-content/uploads/2018/09/42429448_10214066685675325_5757002342838829056_o.jpg)
     Justy Phillips and Margaret Woodward of A Published Event, courtesy Rosie Hastie for #ThePeoplesLibrary and Salamanca Arts Centre
[![](https://garlandmag.com/wp-content/uploads/2018/09/42523604_10214066688835404_4716653026276802560_o-1024x683.jpg)](https://garlandmag.com/wp-content/uploads/2018/09/42523604_10214066688835404_4716653026276802560_o.jpg)
     Justy Phillips and Margaret Woodward of A Published Event, courtesy Rosie Hastie for #ThePeoplesLibrary and Salamanca Arts Centre
[![](https://garlandmag.com/wp-content/uploads/2018/09/42503863_10214066689395418_9003519060473806848_o-1024x683.jpg)](https://garlandmag.com/wp-content/uploads/2018/09/42503863_10214066689395418_9003519060473806848_o.jpg)
     Justy Phillips and Margaret Woodward of A Published Event, courtesy Rosie Hastie for #ThePeoplesLibrary and Salamanca Arts Centre
  

[![](https://garlandmag.com/wp-content/uploads/2018/09/42474171_10214066687795378_888641919091998720_o-1024x683.jpg)](https://garlandmag.com/wp-content/uploads/2018/09/42474171_10214066687795378_888641919091998720_o.jpg)
     Justy Phillips and Margaret Woodward of A Published Event, courtesy Rosie Hastie for #ThePeoplesLibrary and Salamanca Arts Centre
[![](https://garlandmag.com/wp-content/uploads/2018/09/42422384_10214066689875430_8596778557961666560_o-1024x683.jpg)](https://garlandmag.com/wp-content/uploads/2018/09/42422384_10214066689875430_8596778557961666560_o.jpg)
     Justy Phillips and Margaret Woodward of A Published Event, courtesy Rosie Hastie for #ThePeoplesLibrary and Salamanca Arts Centre
[![](https://garlandmag.com/wp-content/uploads/2018/09/42425596_10214066686835354_560215639801724928_o-1024x683.jpg)](https://garlandmag.com/wp-content/uploads/2018/09/42425596_10214066686835354_560215639801724928_o.jpg)
     Justy Phillips and Margaret Woodward of A Published Event, courtesy Rosie Hastie for #ThePeoplesLibrary and Salamanca Arts Centre
  

 
The [Quarterly Essay](https://garlandmag.com/article/quarterly-essay-libraries-of-stone-and-wood/) "Libraries of Stone and Wood" by Justy Phillips and Margaret Woodward of A Published Event included the gestation of a People's Library, made up of previously unpublished manuscripts lovingly published in book form according to an elaborate colour scheme. This "hybrid-performance-library-creature-thing currently unfolding" happened at the Long Gallery, Salamanca Arts Centre, Hobart. We share some images and thoughts from the editors.
It's been an incredible 2 weeks thus far, with 113 books, and over 40 author-generated events. We've had books extended into plays with live jazz accompaniments, Osho meditations, performances, readings, panels, and radio broadcasts. We have welcomed and farewelled our first Reader in Residence, Fayen d'Evie and her two collaborators, Izzy Hardisty and Lizzie Boon from Monash University. Today we welcomed our next Readers in Residence, Unconscious - Collective, who are spending the week in our custom-made bed, social dreaming and digesting the library. Today they were accompanied by an impromptu harp performance by author of book #35, Bone Harps, Tiff Norchick. Tomorrow our final Readers in Residence, Ross Gibson and Kathryn Bird arrive. Surprises and speculative readings at every turn. We've hosted Silent Reading Party, Bright Thinking philosophy cafe, the inaugural Hob/Art Book Fair, students from the School of Creative Arts Hobart (UTAS), the University of the Third Age, an evening of performance poetry by Sholeh Wolpe (Iran/US) and lots more. If you're anywhere near Hobart, come and visit us this week and thank you again for your interest in our work.
