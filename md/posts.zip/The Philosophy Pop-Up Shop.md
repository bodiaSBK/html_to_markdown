﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/philosophy-pop-up-shop
  * Author:: [[Loop]]
  * Tags:: [[consumerism]] [[Melbourne]] [[philosophy]]
  * Date:: [[29 November 2017]]


* * *
[![](http://garlandmag.com/wp-content/uploads/2017/11/T-n-A--300x219.jpg)](http://garlandmag.com/wp-content/uploads/2017/11/T-n-A-.jpg)Regular Garland contributor [Tessa Laird ](http://garlandmag.com/article/dear-adelaida/)has teamed up with a collaborator to develop a very Melbourne exhibition of philosophical objects. The [Philosophy Pop-Up Shop](http://www.kingsartistrun.org.au/program/the-philosophy-pop-up-shop/) applies the creativity of consumerism to the genius of thinkers from Heidegger to Bruno Latour. In case you are worried about the lack of finish in some of the objects, "The Pop-Up Shop’s in-house designer is Plato, whose rough-and-ready style proves that ideas are more important than appearances."
 
 
> [ View this post on Instagram
> ](https://www.instagram.com/p/Bb50QO4AOX5/?utm_source=ig_embed&utm_campaign=loading)
> [TnA Kollective, The Philosophy Pop-Up Shop. Opening last night at Kings, full of gags! + local celebrity philosophy readings today and next two Saturdays #tessalaird #andrewgoodman #kingsari #tnakollective](https://www.instagram.com/p/Bb50QO4AOX5/?utm_source=ig_embed&utm_campaign=loading)
> A post shared by [ Rosemary Forde](https://www.instagram.com/thepeoplespapijackprince/?utm_source=ig_embed&utm_campaign=loading) (@thepeoplespapijackprince) on Nov 24, 2017 at 7:37pm PST
