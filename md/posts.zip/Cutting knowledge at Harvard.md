﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/cutting-knowledge-at-harvard
  * Author:: [[Loop]]
  * Tags:: [[craft thinking]] [[USA]]
  * Date:: [[1 December 2017]]


* * *
[![](http://garlandmag.com/wp-content/uploads/2017/12/Clipboard-Image-300x171-1.jpg)](http://garlandmag.com/wp-content/uploads/2017/12/Clipboard-Image.jpg)It's interesting to see Harvard University initiate this project on the craft basis of knowledge. This video offers a preview of "cutting" as a way of understanding how we make a world, deconstructing our philosophical concepts into material processes. This reflects many of the Garland articles that see culture as a manual phenomenon, such as Lisa Hilli's latest essay on [Embodied history](http://garlandmag.com/article/embodied-history/).
Source: _[Cutting 2017-2018 — Minding Making](https://www.mindingmaking.org/cutting-20172018-1)_
