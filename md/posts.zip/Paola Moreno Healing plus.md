﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/paola-moreno
  * Author:: [[Loop]]
  * Tags:: [[Chile]] [[laurel]] [[textiles]]
  * Date:: [[7 May 2020]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2020/05/IMG_6919.jpg)](https://garlandmag.com/wp-content/uploads/2020/05/IMG_6919.jpg)
     Paola Moreno, Healing, 2020, woven flax leftovers
[![](https://garlandmag.com/wp-content/uploads/2020/05/IMG_6868-768x1024.jpg)](https://garlandmag.com/wp-content/uploads/2020/05/IMG_6868.jpg)
     Paola Moreno, Healing, 2020, woven flax leftovers
[![](https://garlandmag.com/wp-content/uploads/2020/05/IMG_7195-765x1024.jpg)](https://garlandmag.com/wp-content/uploads/2020/05/IMG_7195.jpg)
     Paola Moreno, Healing, 2020, woven flax leftovers
  

[![](https://garlandmag.com/wp-content/uploads/2020/05/IMG_6987-789x1024.jpg)](https://garlandmag.com/wp-content/uploads/2020/05/IMG_6987.jpg)
  

Our May laurel goes to Chilean textile artist Paola Moreno for a beautifully woven yet simple message of positivity for our time.
As Paola Moreno writes:
> La cruz roja es un emblema universal de humanitarismo, también un signo que le dice al mundo que venimos en paz. Y hoy pienso en los dramas que cada uno vive en estos tiempos, más grandes y más pequeños, en compañía o en soledad, en tantos actos cobardes y malvados y en toda la bondad y el amor con que podemos responder ante la dificultad. Ii en el Instagram de la @carosu_xx un texto que decía: “If you can stay positive in a negative situation, you win” ❤️ y desde entonces solo puedo pensar: que así sea
> The red cross is a universal emblem of humanitarianism. It also a sign that tells the world that we come in peace. And today I think of the dramas that each one lives in these times, bigger and smaller, in company or alone, in so many cowardly and wicked acts and in all the kindness and love with which we can respond to difficulties. I saw on Instagram of @carosu_xx a text that said: “If you can stay positive in a negative situation, you win” ❤️ and since then I can only think: so be it.
![](https://garlandmag.com/wp-content/uploads/2020/05/IMG_7158-1024x768.jpg)
Paola Moreno at the loom
Paola Moreno is a textile artist and designer. She teaches at Escuela de Diseño Universidad Católica and Centro de Arte Textile, in Santiago. You can find her on Instagram at [@spaolamorenom](https://www.instagram.com/spaolamorenom/) and [Pinterest](https://www.pinterest.com.au/spmorenom/).
