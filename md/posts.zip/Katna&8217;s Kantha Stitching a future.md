﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/katnas-kantha-stitching-a-future
  * Author:: [[Loop]]
  * Tags:: [[Artisans]] [[India]] [[textiles]]
  * Date:: [[18 December 2017]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2017/12/15740747_1355024201196150_4277997043453555121_n.jpg)](https://garlandmag.com/wp-content/uploads/2017/12/15740747_1355024201196150_4277997043453555121_n.jpg)
[![](https://garlandmag.com/wp-content/uploads/2017/12/home-linen_bedspread2.jpg)](https://garlandmag.com/wp-content/uploads/2017/12/home-linen_bedspread2.jpg)
[![](https://garlandmag.com/wp-content/uploads/2017/12/unnamed.jpg)](https://garlandmag.com/wp-content/uploads/2017/12/unnamed.jpg)
  

This December, Katna’s Kantha by Street Survivors India will make their debut at [ARTISANS](https://www.facebook.com/artisanscentre?fref=ts)’ with a collection of quilts, saris, dupattas and stoles in silk and cotton.The Street Survivors India project was founded by Shabnam Ramaswamy in Murshidabad in 2004 and employs 1500 women in 50 villages.
At 19, Shabnam escaped domestic violence, living in impoverished conditions while trying to support two children. She overcame these challenges to eventually become a social entrepreneur. Shabnam started Katna's Kantha, to provide women with education and financial independence, reviving a local skill unique to the women of Katna. Today their kantha embellishes bags, stoles, saris and dupattas all made by upcycling vintage saris, and turning rags into textile riches.
