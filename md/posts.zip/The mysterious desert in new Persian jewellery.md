﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/the-mysterious-desert-in-new-persian-jewellery
  * Author:: [[Kevin Murray]]
  * Tags:: [[Iran]] [[jewellery]] [[landscape]]
  * Date:: [[27 November 2017]]


* * *
[![](http://garlandmag.com/wp-content/uploads/2017/11/poster-1024x1024.jpg)](http://garlandmag.com/wp-content/uploads/2017/11/poster.jpg)
Putting on the jewellery that carries the nature of the desert, takes us to the journey to reach our inner jewel of silence, where we could sedately observe the truth of being.
A new exhibition of jewellery from the region of Kerman gives unique expression to the mystical meaning of the desert in Persian culture.
[![](http://garlandmag.com/wp-content/uploads/2017/11/statement-The-desert-1024x1024.jpg)](http://garlandmag.com/wp-content/uploads/2017/11/statement-The-desert.jpg)
 
[![](http://garlandmag.com/wp-content/uploads/2017/11/Helia-Hatefi-bagher-Mohseni-4-1024x685.jpg)](http://garlandmag.com/wp-content/uploads/2017/11/Helia-Hatefi-bagher-Mohseni-4.jpg)
Helia Hatefi & Bagher Mohseni
[![](http://garlandmag.com/wp-content/uploads/2017/11/Mona-Saina-pourhosseini-1-1024x1024.jpg)](http://garlandmag.com/wp-content/uploads/2017/11/Mona-Saina-pourhosseini-1.jpg)
Mona & Saina Pourhosseini
