﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/auckland
  * Author:: [[Mari Gold]]
  * Tags:: [[Aotearoa]] [[Auckland]] [[event]] [[launch]]
  * Date:: [[27 November 2017]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2017/12/Garland-9-cover-portrait-c-225x300.png)](https://garlandmag.com/wp-content/uploads/2017/12/Garland-9-cover-portrait-c.png)Join us for the launch of Te Moana nui a Kiwa in Auckland
Saturday 9 December 2017: 4-6:30pm
Objectspace  
13 Rose Rd  
Grey Lynn  
Auckland
Come along to launch Garland #9, featuring an online exhibition curated by Luisa Tora. Lots of karakia, garlanding, poems and talanoa.
[Facebook event.](https://www.facebook.com/events/364023464010088/)
Here are the greetings offered by members of the Garland editorial board:
My name is Freja Carmichael. I am currently in the lovely lands of the Squamish and Lil'Wat people in Canada. I am from the Quandamooka people of Moreton Bay. I live in Meanjin/ Brisbane and thank you for sharing your beautiful stories and objects from Moana
My name is Sana Balai, member of the Nakaripa clan and I come from Buka Island in the Autonomous Region of Bougainville and I live in Melbourne. I'm enjoying your beautiful work in Garland.
My name is Damien Wright, Snowy, Spider, Bonguwa and Barpung.I live on the lands of the Kulin Nation in Preston. A post-industrial suburban fantasy. The six of us live on a South facing hill with two dogs, two cats, five chickens, two rabbits and a constant stream of fruit bats feeding of our Lilly Pilli. We overlook the Delta on Melbourne and its three creeks. We are warmed by the North wind and watch the endless Southern storms roll in from the Southern Ocean. To share and learn the values of our Pacific cousins is a life worth living.
Kai friends from New Zealand. My name is Valeria, I live in Mexico City, and I would love to learn about your Pacific crafts and values, see what we share in common, know your perspective. In other words: Travel by looking at your making.
I am in Seoul, Korea promoting its craft around the world. We are at the forefront in representing our craft culture through the philosophy of preserving tradition by finding new ways to present it - the concept of constancy and change. Sending warmest regards to Garland for all its achievements since it has been established in 2015. I give my full support and I wish for it to flourish in the future!!! Well done so far!
My name is Frans Panjaitan. I live in Bandung, the flower city of Indonesia. Coming from Indonesia, with thousands of crafts and traditions, I am very pleased to learn about Pacific crafts and how the difference between our culture could result in equally beautiful objects. And hope we could learn from each other
Hi there! My name is Ishan Khosla and I currently live in Delhi, India. As someone who has been to New Zealand and loves the Maori culture, I am excited to read about the crafts of the region. BTW: the Garland logo looks very "Kiwi" right now to me!
"Hola, soy Paola Moreno, artista textil de Santiago de Chile y les envío un saludo de respeto y admiración por el maravilloso trabajo desplegado en este número de Garland. Felicitaciones y larga vida a los tejedores del otro lado del Pacífico"
My name is Olivia Hamilton. I live in Melbourne and teach at Rmit. It is wonderful to hear your stories and learn more about the Pacific crafts and values.
My name is Michelle Boyde, I live in a very beautiful part of South East Tasmania off the Tasman Sea called Boomer Bay, and I'm very interested to learn about Pacific crafts and values.
