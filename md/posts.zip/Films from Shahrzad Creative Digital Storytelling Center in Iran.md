﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/films-from-shahrzad-creative-digital-storytelling-center-in-iran
  * Author:: [[Loop]]
  * Tags:: [[film]] [[Iran]]
  * Date:: [[18 December 2017]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2017/12/photo_2017-12-13_13-43-54-1024x414.jpg)](https://garlandmag.com/wp-content/uploads/2017/12/photo_2017-12-13_13-43-54.jpg)
[![](https://garlandmag.com/wp-content/uploads/2017/12/photo_2017-12-13_13-43-43-1024x316.jpg)](https://garlandmag.com/wp-content/uploads/2017/12/photo_2017-12-13_13-43-43.jpg)
  

A glimpse of the creative energy emerging with a new generation in Iran, keen to tell the stories of their wonderful crafts. 
Shahrzad Creative Digital Storytelling Center (shahrzadcdsc) is a cultural Institute which was formed in 2012. As the first group of its kind in Iran, and probably in the Middle East as well, they put much effort in localising this medium to our region needs. 
A teen tells her story based on her experience of Parviz tanavoli and the _Lions of Iran_ exhibition at the temporary art museum in Tehran.
 _Tajmir, a village for dolls_ is a part of Museum of Culture and traditional Dolls of Khorasan Province program in collaboration with Cultural Heritage, Handicrafts and Tourism organization of Khorasan Province, Carbon Sequestration Project (CSP) and Traditional Doll Museum in Tehran.
