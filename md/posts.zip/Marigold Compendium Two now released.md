﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/marigold
  * Author:: [[Loop]]
  * Tags:: [[compendium]] [[Mexico]]
  * Date:: [[15 November 2018]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2018/11/20181031_212945-225x300.jpg)](https://garlandmag.com/wp-content/uploads/2018/11/20181031_212945.jpg)Each year of Garland's journey we publish a hard copy selection of stories from across the Indo-Pacific. In the Marigold issue, we travel to Western India, Thai villages, Australian towns and the legendary island of Bali. Our Marigold edition includes the stories behind the object, reflecting the deep cultural values that flourish in our wide world.
This can be purchased for $AUD 40 [here](http://au.blurb.com/b/8975651-marigold-compendium-two#).
In the Mexican festival of El Dia de Los Muertos, petals from the marigold (cempazuchitly) are strewn in a path from the cemetery to the altar (ofrenda) in the family home. This guides the souls of the dead back home for the day when memories of the departed are celebrated.
We were able[ to launch this issue in Oaxaca](https://garlandmag.com/loop/zapotechnology/) for this festival and it is now housed in [La Calera](https://www.lacalera.org/), where you can see it be read avidly by its director, Luis Jesus Torres Ruiz.
