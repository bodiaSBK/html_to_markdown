﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/sitaben
  * Author:: [[Loop]]
  * Tags:: [[event]] [[India]] [[jewellery]] [[LOkesh Ghai]]
  * Date:: [[7 December 2020]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2020/12/sitaben-event-1.jpg)](https://garlandmag.com/wp-content/uploads/2020/12/sitaben-event-1.jpg)
Listen to stories by Gauri Raje about the bead jewellery by Sitaben Chavda, a unique maker from Ahmedabad.
Online on Sunday 20 December 8am (London), 1:30pm (India), 7pm (AEDT)
We continue our series of events that connect directly to storymakers who use their crafts to tell traditional tales. These events offer support for traditional makers during a time of reduced opportunities and hardship. Gauri Raje is a professional storyteller who activates the objects by masterful Sitaben, a bead jewellery maker from Ahmedabad. This offering is masterminded by LOkesh Ghai. You can book below or [here](https://www.eventbrite.com.au/e/the-heart-of-the-necklace-a-reverse-sleeping-beauty-story-tickets-131817235901).
* * *
