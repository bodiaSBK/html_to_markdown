﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/ithongo-messages-from-the-ancestors
  * Author:: [[Loop]]
  * Tags:: [[ceramics]] [[musical instrument]] [[revival]] [[South Africa]] [[Xhosa]]
  * Date:: [[22 December 2020]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.76.LR_-1024x684.jpg)](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.76.LR_.jpg)
[![](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.105.LR_-1024x684.jpg)](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.105.LR_.jpg)
[![](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.163.LR_-1024x682.jpg)](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.163.LR_.jpg)
  

[![](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.53.LR_-1024x684.jpg)](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.53.LR_.jpg)
[![](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.55.LR_-1024x684.jpg)](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.55.LR_.jpg)
[![](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.44.LR_-1024x684.jpg)](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.44.LR_.jpg)
  

[![](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.05.LR_-684x1024.jpg)](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.05.LR_.jpg)
[![](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.121.LR_-1024x684.jpg)](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.121.LR_.jpg)
[![](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.110.LR_-684x1024.jpg)](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.110.LR_.jpg)
  

[![](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.133.LR_-846x1024.jpg)](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.133.LR_.jpg)
[![](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.131.LR_.jpg)](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.131.LR_.jpg)
[![](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.45.LR_-1024x684.jpg)](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.45.LR_.jpg)
  

[![](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.91.LR_-684x1024.jpg)](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.91.LR_.jpg)
[![](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.32.LR_-684x1024.jpg)](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.32.LR_.jpg)
[![](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.153.LR_-684x1024.jpg)](https://garlandmag.com/wp-content/uploads/2020/12/AndileDyalvane_iThongo_2020_EasternCape_Cr.AdriaanLouwSGuildFriedmanBenda.153.LR_.jpg)
  

Andile Dyalvane's new work inscribes Xhosa objects into ceramic seating that supports a gathering of his OoJola clan.
South African ceramicist Andile Dyalvane has produced a body of work for display in Cape Town ([Southern Guild](https://southernguild.co.za/)) and New York ([Friedman Benda](http://www.friedmanbenda.com/)). His ceramic seating relates to Xhosa ceremonial gatherings.
 _iThongo_ means “ancestral dreamscape” in Xhosa. It refers to the medium through which messages ( _uYalezo_ _uLwimi lwabaPhantsi_ ) are transmitted from the ancestors.
Andile states: “My intentions with developing an extended body of work under the title iThongo is to highlight a gathering of dreams, seated in the soul, held by the spirits of our ancestors. Symbols are visual tools harnessed to more effectively impart meanings within _messa_ —codes, if you will—that aid stories. The language of dreams is symbolic and therefore realised as _uyalezo_ , messages from our ancestral spirits.”
iThongo includes 18 ceramic stools, chairs and benches exhibited according to Xhosa tradition in a circle around a fire hearth with herbal offerings. The works are hand-coiled in terracotta clay and almost a metre tall. Each form is based on a single pictogram or glyph from a series of close to 200 symbols that Dyalvane has designed to denote important words in Xhosa life, such as _entshonalanga_ (sunset), _igubu_ (drum), _umalusi_ (herdsman) and _izilo_ (totem animals). They also relate to the natural world and more universal human themes and concepts.
Their debossed forms emerge from and dissolve into the sculptures’ clay surface, an effect created using tools such as carved stamps and linocut tiles. The objects are curved and spherical, echoing the traditional rondavel structures and kraal enclosures in which livestock are kept. Circular geometry is believed to facilitate a free exchange of energy in Xhosa spiritual practices in keeping with the organic shapes found in nature.
One of the pictograms references an important Xhosa instrument.
### iGubu (Drum)
![](https://garlandmag.com/wp-content/uploads/2020/12/6E80C1CF-1482-4036-A406-5E70D6641C19.png)The vibration of sound, particularly the Gubu Drum (a cattle skin stretched tightly over two sides of circular metal plates, a hollow centre), coined the ‘Xhosa Drum’ is essential to ceremonial healing practices. It connects all who hear it to their truths, having travelled the sonic landscapes of their mother's heart from her womb. The vibrations of her heart enable the song of your heart to join in a unified presence, welcoming your arrival into the great energy of being transformed. The village community I grew up in as well as my family incorporate the transformative vibrational energy of the Gubu drum beat when we gather to remember our ancestral heartbeat and ancient belonging. Music is important in my own creative process.  
Nkuthazo Dyalvane concludes:
"Dyalvane through clay gifts of iThongo (Ancestral Dreamscape) energises uYalezo uLwimi lwabaPhantsi (messages from our ancestors) to welcome those who are guided toward this holding space of collective reminding of our truths—expounding healing of collective trauma by collectively communing to reverberate light. These are cyclical symbolisms of unified light journeys, we all can join. Those who sit here, engage with eThongweni—the great spirit of belonging—of HOME."
The images in this story come from a gathering of his OoJola clan of the Xhosa people in the village of Ngobozana, near Qobo-Qobo in the Eastern Cape. The photos are by Adriaan Louw, courtesy of Southern Guild/Friedman Benda
Ngobozana, Eastern Cape | 21 – 22 November, 2020  
Southern Guild, Cape Town | 10 December, 2020 – 4 March, 2021  
Friedman Benda, New York | 3 June – 2 July, 2021
You can follow Andile Dyalvane at @[imisoceramics](https://instagram.com/imisoceramics) or visit [www.imisoceramics.co.za](https://www.imisoceramics.co.za/). In December 2018, Andile was honoured with a [](https://garlandmag.com/loop/andile-dyalvane/)  
Garland Laurel for his uTyityilizi vessel.
 
