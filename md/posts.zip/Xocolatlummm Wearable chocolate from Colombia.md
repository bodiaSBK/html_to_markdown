﻿
  * Source:: [[Garland magazine]]
  * URL:: https://garlandmag.com/loop/xocolatlummm
  * Author:: [[Mari Gold]]
  * Tags:: [[chocolate]] [[Colombia]] [[jewellery]] [[Spain]]
  * Date:: [[29 November 2017]]


* * *
[![](https://garlandmag.com/wp-content/uploads/2017/11/Image_001-1024x804.jpg)](https://garlandmag.com/wp-content/uploads/2017/11/Image_001.jpg)
[![](https://garlandmag.com/wp-content/uploads/2017/11/Image_011.png)](https://garlandmag.com/wp-content/uploads/2017/11/Image_011.png)
[![](https://garlandmag.com/wp-content/uploads/2017/11/Image_009.jpg)](https://garlandmag.com/wp-content/uploads/2017/11/Image_009.jpg)
  

Our friend [Ana Berrio](http://garlandmag.com/article/geodenim-ornament-from-the-streets-of-medellin/) shares another remarkable project of Colombian street jewellery. For Joya Barcelona recently, she made a cart decorated in typical style and sold body ornaments made from chocolate for €10 each. Xocolatlummm included artists Titi Berrio, Alejandra Ferrer and Liliana Molina.
Check the Instagram [account](https://www.instagram.com/xocolatlummm/):
> [ View this post on Instagram
> ](https://www.instagram.com/p/BaFcytQlGQ8/?utm_source=ig_embed&utm_campaign=loading)
> [A post shared by xocolatlummm (@xocolatlummm)](https://www.instagram.com/p/BaFcytQlGQ8/?utm_source=ig_embed&utm_campaign=loading) on Oct 10, 2017 at 4:00pm PDT
 
